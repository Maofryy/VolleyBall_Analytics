INSERT INTO sport_analytics.users (first_name,last_name,email,password,licence,pseudo,created_at,active,updated_at,email_verified_at,remember_token) VALUES
	 ('Cherokee','Weber','voriqiteju@mailinator.com','$2y$10$XGqGot4tpYiSWXBeot89v.gNPj0fvVMNh8YfFvRaSLaRQXqcB/ee.',NULL,NULL,'2022-02-19 15:41:43',NULL,'2022-02-19 15:41:43',NULL,NULL),
	 ('Fiona','Carey','zawubu@mailinator.com','$2y$10$jaT9QGw7ymeNSPjnNTp8Nud4KQ6Rdrt/cKF9C69x4Dg6QcETVBkgW',NULL,NULL,'2022-02-19 16:24:26',NULL,'2022-02-19 16:24:26',NULL,NULL),
	 ('Ahmed','Warren','zubugiwif@mailinator.com','$2y$10$HxRHuEinLOdJobjG/UPwyuKB.djmfy.Fc.vP8WrKbrvSWfX2eMr0S',NULL,NULL,'2022-02-19 16:25:36',NULL,'2022-02-19 16:25:36',NULL,NULL),
	 ('Isadora','Stafford','vyfi@mailinator.com','$2y$10$R6idEgEH483./NNRufk6Z.yGaW/82xVObnDmbnBnhJ6OSvUc9dW2i',NULL,NULL,'2022-02-19 16:25:58',NULL,'2022-02-19 16:25:58',NULL,NULL),
	 ('Nehru','Weiss','xidakacolo@mailinator.com','$2y$10$YKprFKJkL0br2k.TIoEHn.CqiFO9PfzyGk06G7.DCPBwnWplIVrBG',NULL,NULL,'2022-02-19 16:27:13',NULL,'2022-02-19 16:27:13',NULL,NULL),
	 ('Admin','Admin','admin@admin.admin','$2y$10$8dqINOGQoSn2G4a911k7sejtuj6qHfTe3qfaSnM3WGoz7MLCjNacm',NULL,NULL,'2022-02-19 16:33:11',NULL,'2022-02-19 16:33:11',NULL,NULL),
	 ('Samantha','Eaton','hytoro@mailinator.com','$2y$10$oLylU/qHt4uFS0s82Bqp3uBOed2t58wqZCYhILQFGfuUfGvHiB0Pm',NULL,NULL,'2022-02-19 19:14:22',NULL,'2022-02-19 19:14:22',NULL,NULL),
	 ('Carlos','Pacheco','fuci@mailinator.com','$2y$10$ufMrX7rEj4KEWErW1cU99.Rvy2ob1Vvkzl89jmch67Ig3MsLfx0wS',NULL,NULL,'2022-02-19 19:18:01',NULL,'2022-02-19 19:18:01',NULL,NULL),
	 ('Wyoming','Delaney','rerupy@mailinator.com','$2y$10$v3AGKcZJje7aSjIzVZdrAuSLn0OTNYTUcFVLF.7meupipKaKcDD16',NULL,NULL,'2022-02-19 19:21:08',NULL,'2022-02-19 19:21:08',NULL,NULL),
	 ('Francesca','Cash','maqohy@mailinator.com','$2y$10$3CBqrhB9q9Ova7J5Ps/hze.Q46vSDpgsRBwDNcGBD2NnEkFEQjf2C',NULL,NULL,'2022-02-19 19:21:28',NULL,'2022-02-19 19:21:28',NULL,NULL);
INSERT INTO sport_analytics.users (first_name,last_name,email,password,licence,pseudo,created_at,active,updated_at,email_verified_at,remember_token) VALUES
	 ('Fallon','Lancaster','gahu@mailinator.com','$2y$10$spTaCN/MBvd9fniM8/Eoz.Uhf5FepZK4pzNYoub9Irz0ZTHsOUWvW',NULL,NULL,'2022-02-19 19:22:04',NULL,'2022-02-19 19:22:04',NULL,NULL),
	 ('Ethan','Stafford','luqacozudo@mailinator.com','$2y$10$r4tuEAELG3uTGuXsLF2AEupOsSVP5.ALpzcyoofgXbEurA2Qa2Qgy',NULL,NULL,'2022-02-19 19:30:48',NULL,'2022-02-19 19:30:48',NULL,NULL),
	 ('Nomlanga','Golden','qesopocab@mailinator.com','$2y$10$keO/6COCe8GQXemAuceS1usMMjqYY9eUCujYuwjzdSRX6d7zEWtsu',NULL,NULL,'2022-02-19 19:32:26',NULL,'2022-02-19 19:32:26',NULL,NULL),
	 ('Giselle','Knight','kivysiko@mailinator.com','$2y$10$/4ncPH7Le3OKRTEDvi.zDuuW.FpdAE83qoi6IjAg.b4dvuk9VpjOm',NULL,NULL,'2022-02-19 19:33:36',NULL,'2022-02-19 19:33:36',NULL,NULL),
	 ('John','Doe','john@gmail.com','$2y$10$hXxmeNvcrFMll9tnw3i9e.1SFGNnGTldLcqsbI/JBUXbEbhW4QNQO',NULL,NULL,'2022-02-19 19:34:37',NULL,'2022-02-19 19:34:37',NULL,NULL),
	 ('Caldwell','Hensley','roganig@mailinator.com','$2y$10$ScbYxUQTyFP784Jeayi/u.sZT3CL.7TBJbTgz.oOhE.Rst21aaWJ2',NULL,NULL,'2022-02-19 19:35:56',NULL,'2022-02-19 19:35:56',NULL,NULL),
	 ('Plato','Collier','laluwawef@mailinator.com','$2y$10$EduSrFgxVVHHERifOdkliuYEz1iZ75psu7kaO6wkik1R8uz0TmAcK',NULL,NULL,'2022-02-19 19:36:05',NULL,'2022-02-19 19:36:05',NULL,NULL),
	 ('Wilma','Guy','docywiguc@mailinator.com','$2y$10$0ZpP6cFU6nI66BAPD2Rz5uUHWKjQ7lOH382vqTiwthwj66jIyNTa2',NULL,NULL,'2022-02-19 19:40:14',NULL,'2022-02-19 19:40:14',NULL,NULL),
	 ('Bree','Bishop','juxa@mailinator.com','$2y$10$djl1al6Gcy0FML.Hsikc4OUSUb73ciKL.v3qHPnPJtMyIRywc0uya',NULL,NULL,'2022-02-19 19:40:59',NULL,'2022-02-19 19:40:59',NULL,NULL),
	 ('Ila','Cox','maxevy@mailinator.com','$2y$10$/ASKjHBli8uaEpJC2LXdSO7QiZMOXXxqGG1KjE74FCwcutswHlNVW',NULL,NULL,'2022-02-19 19:41:30',NULL,'2022-02-19 19:41:30',NULL,NULL);
INSERT INTO sport_analytics.users (first_name,last_name,email,password,licence,pseudo,created_at,active,updated_at,email_verified_at,remember_token) VALUES
	 ('Kylee','Osborn','cupiqi@mailinator.com','$2y$10$h0ARPM7nW/fLYdzPQVac9uILqkVSqKuJCUnvZ1s5HV0vDMjxIEFWa',NULL,NULL,'2022-02-19 19:42:24',NULL,'2022-02-19 19:42:24',NULL,NULL),
	 ('Dylan','Moss','jyqilud@mailinator.com','$2y$10$og/jazp8l2Wu5gd4ewzm0OaD//CRcl4vA8ucCjd/U..q0fmjkwSCi',NULL,NULL,'2022-02-19 19:50:26',NULL,'2022-02-19 19:50:26',NULL,NULL),
	 ('Cedric','Whitehead','sezocuk@mailinator.com','$2y$10$1tkwjYh2K2XetiQRA0Mn.OWzcYCjrs36WBfKYvyCYlPRU9yW/j0JS',NULL,NULL,'2022-02-19 19:51:38',NULL,'2022-02-19 19:51:38',NULL,NULL),
	 ('Hermione','Cannon','wagewy@mailinator.com','$2y$10$46wLtxuClA722fKZyQCBRO13gmZYZmKAW6IyKe9zhJUsLZF5sohCu',NULL,NULL,'2022-02-19 19:52:27',NULL,'2022-02-19 19:52:27',NULL,NULL),
	 ('Lamar','Richardson','lyxofydogi@mailinator.com','$2y$10$F60G141v6Lt4O0WuR.0XIuDqyWExr88NVFfaM5v7LWAFT/r5BEHzi',NULL,NULL,'2022-02-19 19:53:24',NULL,'2022-02-19 19:53:24',NULL,NULL),
	 ('Iona','Love','buvebynu@mailinator.com','$2y$10$amRrh8YwohfXth8q/p4inO7PE93/9tmXQli0NpWm024R7fJaO9P9.',NULL,NULL,'2022-02-19 19:54:16',NULL,'2022-02-19 19:54:16',NULL,NULL),
	 ('Wing','Reid','kusykawo@mailinator.com','$2y$10$6i2o/tlaciAytWU.OWeBQeAopDBHymnx8hE3jDPbapQ.aI7WCM6.S',NULL,NULL,'2022-02-19 20:03:19',1,'2022-02-19 20:03:19',NULL,NULL);